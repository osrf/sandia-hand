Board: armh-finger-mcb
Revision: 5

Fabrication Notes
===========================================================================
Black soldermask both sides
White silkscreen both sides
Gold immersion finish
6 layers
31-mil stackup, FR4 is fine
5 mil trace/space
8 mil minimum hole size, 6 mil minimum annular ring
1.208 inches wide
3.081 inches tall
Two circular interior cutouts as shown in the "outline" gerber layer
Desired quantity of pcb fab is the nearest full-panel yield beyond 36 boards.
Please place in whichever array format is most convenient for Sierra Assembly.

Assembly Notes
===========================================================================
SMT both sides
144 SMT components, zero through-hole components
All components have digikey part numbers in armh-finger-mcb.bom.xls
XYRS data provided in armh-finger-mcb.xyrs.xls
Desired quantity of assembled and separated pcb's is 36 boards.


Contact
===========================================================================
Morgan Quigley
Open Source Robotics Foundation
morgan@osrfoundation.org

